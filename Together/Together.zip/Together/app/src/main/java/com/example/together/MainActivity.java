package com.example.together;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    ViewPager vpMain;
    TabLayout tlMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vpMain = findViewById(R.id.vpMain);
        tlMain = findViewById(R.id.tlMain);

        configureBottomNavigation();
    }

    private void configureBottomNavigation() {
        vpMain.setAdapter(new MainFragmentPagerAdapter(getSupportFragmentManager(), 4));

        View bottomNavLayout = this.getLayoutInflater().inflate(R.layout.bottom_navigation_tab, null, false);
        tlMain.getTabAt(0).setCustomView(bottomNavLayout.findViewById(R.id.surroundingsTab));
        tlMain.getTabAt(1).setCustomView(bottomNavLayout.findViewById(R.id.feelingFragment));
        tlMain.getTabAt(2).setCustomView(bottomNavLayout.findViewById(R.id.sosFragment));
        tlMain.getTabAt(3).setCustomView(bottomNavLayout.findViewById(R.id.myFragment));
    }

}