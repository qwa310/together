package com.example.together

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter

class MainFragmentPagerAdapter(fm : FragmentManager, val fragmentCount : Int) : FragmentStatePagerAdapter(fm) {
    override fun getItem(position: Int): Fragment {
        return when(position){
            0 -> SurroundingsFragment()
            1 -> FeelingFragment()
            2 -> SosFragment()
            else -> MyFragment()
        }
    }

    override fun getCount(): Int = fragmentCount

}